import matplotlib.pyplot as plt
import numpy as np
kt = 3.018150 #unit kj/mol
xmin = -0.034936
xmax = 1.393851
ymin = 0.836291
ymax = 1.763875
z = np.loadtxt("direct_reweight_quantity.dat")
Z = -kt*np.log(z)
Z = Z.T
plt.imshow(Z[1].reshape(72,47), cmap=plt.cm.viridis, vmin=-20, vmax=12,
            extent=[xmin, xmax, ymin, ymax])

plt.savefig('NN.png', dpi=300, orientation='landscape', format='png',frameon=None)
