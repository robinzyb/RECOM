from utils.tools import plot_example02, plot_uncertainty
import numpy as np
import matplotlib.pyplot as plt
x = np.loadtxt("../Li-O/other_data/gr_5_Li-O.dat", usecols=0).T

#grs = np.vstack((gr1, gr2, gr3, gr4, gr5))
#plot_example02(direct_reweight, asym_reweight, grs, x)

#dev = asym_reweight.std(axis=0)
com_md_1 = np.loadtxt("../Li-O/input/gr_list_Li-O.dat")
com_md_1 = com_md_1.mean(axis=0)
com_md_2 = np.loadtxt("../Be-O/input/gr_list_Be-O.dat")
com_md_2 = com_md_2.mean(axis=0)
com_md_3 = np.loadtxt("../He-O/input/gr_list_He-O.dat")
com_md_3 = com_md_3.mean(axis=0)


plt.plot(x, com_md_1, label = "Li-O")
plt.plot(x, com_md_2, label = "Be-O")
plt.plot(x, com_md_3, label = "He-O")
plt.legend()
plt.show()
