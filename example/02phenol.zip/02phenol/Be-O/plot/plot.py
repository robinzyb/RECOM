from utils.tools import plot_example02, plot_uncertainty
import numpy as np
direct_reweight = np.loadtxt("../direct_reweight_quantity.dat").T
asym_reweight = np.loadtxt("../asymptotic_reweight_quantity.dat").T

gr1 = np.loadtxt("../other_data/gr_1_Be-O.dat", usecols=1).T
gr2 = np.loadtxt("../other_data/gr_2_Be-O.dat", usecols=1).T
gr3 = np.loadtxt("../other_data/gr_3_Be-O.dat", usecols=1).T
gr4 = np.loadtxt("../other_data/gr_4_Be-O.dat", usecols=1).T
gr5 = np.loadtxt("../other_data/gr_5_Be-O.dat", usecols=1).T
x = np.loadtxt("../other_data/gr_5_Be-O.dat", usecols=0).T

grs = np.vstack((gr1, gr2, gr3, gr4, gr5))
plot_example02(direct_reweight, asym_reweight, grs, x)

dev = asym_reweight.std(axis=0)
com_md = np.loadtxt("../input/gr_list_Be-O.dat")
com_md = com_md.mean(axis=0)
plot_uncertainty(com_md, dev, x)
